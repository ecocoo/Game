﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace kitchen
{
    public class Customer
    {
        private Texture2D texture;
        private Vector2 position;
        private Random random = new Random();
        private double timeLeft;
        private Dictionary<string, DishCategory> allDishes;
        private DishManager dishManager;
        public string CurrentDish { get; private set; }
        public bool NeedsNewDish => timeLeft <= 0;


        public Customer(Texture2D texture, int screenWidth, Dictionary<string, DishCategory> allDishes, DishManager dishManager, List<string> initialDishes)
        {
            this.texture = texture;
            position = new Vector2((screenWidth - this.texture.Width * 0.2f) / 2, 10);
            this.allDishes = allDishes;
            this.dishManager = dishManager;
            ChooseNewDish();
        }

        public void ChooseNewDish()
        {
            if (allDishes.Count > 0)
            {
                List<string> availableDishes = new List<string>(allDishes.Keys);
                int index = random.Next(availableDishes.Count);
                CurrentDish = availableDishes[index];
                timeLeft = 10.0; 
                AddDishToManager(CurrentDish);
            }
        }

        private void AddDishToManager(string dishName)
        {
            if (!dishManager.Exists(dishName))
            {
                dishManager.AddDish(dishName, allDishes[dishName]);
            }
        }

        public bool PositionClose(Vector2 playerPosition)
        {
            const float threshold = 100.0f;
            return Vector2.Distance(position, playerPosition) <= threshold;
        }

        public bool WaitingDish(Dish dish)
        {
            return CurrentDish != null && dish.Name == CurrentDish;
        }

        public void ReceiveDish(Dish dish, Player player)
        {
            if (WaitingDish(dish) && PositionClose(player.Position))
            {
                player.DropDish();
                player.IncreaseScore(3);
                ChooseNewDish();
            }
            else
            {
                player.DropDish();
                if (!WaitingDish(dish))
                {
                    player.DecreaseScore(3); 
                }

                AddRandomDishToManager();
                AddRandomDishToManager();
                AddRandomDishToManager();
                ChooseNewDish();
            }
        }

        private void AddRandomDishToManager()
        {
            var keysList = new List<string>(allDishes.Keys);
            string randomDishName = keysList[random.Next(keysList.Count)];
            AddDishToManager(randomDishName);
        }


        public void Update(GameTime gameTime, Player player)
        {
            timeLeft -= gameTime.ElapsedGameTime.TotalSeconds;


            if (NeedsNewDish)
            {
                if (player.IsHoldingDish())
                {
                    player.DropDish();
                    player.DecreaseScore(1);
                }

                player.DecreaseScore(2);
                AddRandomDishToManager();
                ChooseNewDish();
            }
        }


        public void Draw(SpriteBatch spriteBatch, SpriteFont font)
        {
            spriteBatch.Draw(texture, position, null, Color.White, 0f, Vector2.Zero, 0.2f, SpriteEffects.None, 0f);
            Vector2 infoPosition = position + new Vector2(100, 0); 

            if (!string.IsNullOrEmpty(CurrentDish))
            {
                Vector2 dishTextPosition = infoPosition + new Vector2(0, 20); 
                spriteBatch.DrawString(font, CurrentDish, dishTextPosition, Color.Black);
            }
            if (timeLeft > 0)
            {
                string timeLeftText = $"Time left: {timeLeft:F1}s";
                Vector2 timeTextPosition = infoPosition + new Vector2(0, 40);
                spriteBatch.DrawString(font, timeLeftText, timeTextPosition, Color.Red);
            }
        }
    }
}
