﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;

public class Runner
{
    private Vector2 position;
    public Vector2 Position => position;
    private Texture2D texture;
    private float speed;
    private int screenWidth;
    private int screenHeight;
    private Vector2 scale;
    private bool leftToRight;

    public Runner(Texture2D texture, int screenWidth, int screenHeight, Vector2 scale, bool leftToRight)
    {
        this.texture = texture;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.scale = scale;
        this.leftToRight = leftToRight;
        speed = 7.0f;
        ResetPosition();
    }

    private int RandomHeight()
    {
        Random random = new Random();
        return random.Next(170, 400);
    }

    private void ResetPosition()
    {
        if (leftToRight)
        {
            position = new Vector2(-texture.Width * scale.X, RandomHeight());
        }
        else
        {
            position = new Vector2(screenWidth, RandomHeight());
        }
    }

    public bool CheckCollision(Rectangle playerBounds, Player player, DishManager dishManager)
    {
        int collisionWidth = (int)(texture.Width * 0.1f);
        int collisionHeight = (int)(texture.Height * 0.1f);
        int xOffset = (int)(texture.Width * 0.15f);
        int yOffset = (int)(texture.Height * 0.15f);

        Rectangle runnerCollisionRect = new Rectangle((int)position.X + xOffset, (int)position.Y + yOffset, collisionWidth, collisionHeight);

        if (runnerCollisionRect.Intersects(playerBounds))
        {
            if (player.IsHoldingDish())
            {
                dishManager.ReturnDishToPosition(player.HeldDish);
                player.DropDish();
            }
            return true;
        }
        return false;
    }


    public void Update(GameTime gameTime)
    {
        if (leftToRight)
        {
            position.X += speed;
            if (position.X > screenWidth)
            {
                ResetPosition();
            }
        }
        else
        {
            position.X -= speed;
            if (position.X < -texture.Width * scale.X)
            {
                ResetPosition();
            }
        }
    }

    public void Draw(SpriteBatch spriteBatch)
    {
        spriteBatch.Draw(texture, position, null, Color.White, 0, Vector2.Zero, scale, SpriteEffects.None, 0);
    }
}

