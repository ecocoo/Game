﻿using kitchen;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

public class MainMenu
{
    private SpriteFont font;
    private Texture2D backgroundTexture;
    private Rectangle playButton;
    private Rectangle rulesButton;
    private Rectangle exitButton;
    private string rulesText;
    private bool showingRules;
    private int screenWidth;
    private int screenHeight;

    public MainMenu(SpriteFont font, Texture2D backgroundTexture, int screenWidth, int screenHeight)
    {
        this.font = font;
        this.backgroundTexture = backgroundTexture;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;

        int buttonWidth = 200;
        int buttonHeight = 50;
        int buttonYStart = screenHeight / 2 - 100;

        playButton = new Rectangle(screenWidth / 2 - buttonWidth / 2, buttonYStart, buttonWidth, buttonHeight);
        rulesButton = new Rectangle(screenWidth / 2 - buttonWidth / 2, buttonYStart + 70, buttonWidth, buttonHeight);
        exitButton = new Rectangle(screenWidth / 2 - buttonWidth / 2, buttonYStart + 140, buttonWidth, buttonHeight);

        rulesText = "Управление:\nWASD - двигаться\nF - поднять блюдо\nSpace - выкинуть блюдо\nR - отдать блюдо\nЕсли ты наберешь -10 очков, игра закончится";
        showingRules = false;
    }

    public void Update(Game1 game, GameTime gameTime)
    {
        MouseState mouseState = Mouse.GetState();

        if (showingRules)
        {
            if (mouseState.LeftButton == ButtonState.Pressed)
            {
                showingRules = false;
            }
        }
        else
        {
            if (playButton.Contains(mouseState.Position) && mouseState.LeftButton == ButtonState.Pressed)
            {
                game.StartGame();
            }
            else if (rulesButton.Contains(mouseState.Position) && mouseState.LeftButton == ButtonState.Pressed)
            {
                showingRules = true;
            }
            else if (exitButton.Contains(mouseState.Position) && mouseState.LeftButton == ButtonState.Pressed)
            {
                game.Exit();
            }
        }
    }

    public void Draw(SpriteBatch spriteBatch)
    {
        spriteBatch.Draw(backgroundTexture, new Rectangle(0, 0, screenWidth, screenHeight), Color.White);

        if (showingRules)
        {
            Vector2 textSize = font.MeasureString(rulesText);
            Vector2 textPosition = new Vector2(screenWidth / 2 - textSize.X / 2, screenHeight / 2 - textSize.Y / 2);
            spriteBatch.DrawString(font, rulesText, textPosition, Color.Black);
        }
        else
        {
            DrawButton(spriteBatch, playButton, "Играть");
            DrawButton(spriteBatch, rulesButton, "Правила");
            DrawButton(spriteBatch, exitButton, "Выйти");
        }
    }

    private void DrawButton(SpriteBatch spriteBatch, Rectangle buttonRect, string text)
    {
        spriteBatch.Draw(backgroundTexture, buttonRect, Color.Gray);
        Vector2 textSize = font.MeasureString(text);
        Vector2 textPosition = new Vector2(buttonRect.X + (buttonRect.Width - textSize.X) / 2, buttonRect.Y + (buttonRect.Height - textSize.Y) / 2);
        spriteBatch.DrawString(font, text, textPosition, Color.Black);
    }
}
