﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

public class Dish
{
    public string Name { get; private set; }
    public Vector2 Position { get; private set; }
    public DishCategory Category { get; private set; }
    public Texture2D Texture { get; private set; }
    public Vector2 InitialPosition { get; private set; }

    public Dish(string name, DishCategory category, Vector2 position, Texture2D texture)
    {
        Name = name;
        Category = category;
        Position = position;
        InitialPosition = position;
        Texture = texture;
    }

    public void Draw(SpriteBatch spriteBatch)
    {
        float scale = 0.2f;
        spriteBatch.Draw(Texture, Position, null, Color.White, 0f, Vector2.Zero, scale, SpriteEffects.None, 0f);
    }

    public void ResetPosition()
    {
        Position = InitialPosition;
    }
}
