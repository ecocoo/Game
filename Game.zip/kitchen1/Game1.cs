﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace kitchen
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;
        private Player player;
        private Customer customer;
        private Texture2D customerTexture;
        private Texture2D playerTexture;
        private Texture2D runnerTexture;
        private SpriteFont font;
        private DishManager dishManager;
        private Runner runner;
        private Runner leftRunner;
        private Texture2D backgroundTexture;
        private MainMenu mainMenu;
        private bool gameStarted;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            graphics.PreferredBackBufferWidth = 1000;
            graphics.PreferredBackBufferHeight = 700;
            graphics.IsFullScreen = false;
            gameStarted = false;
        }

        protected override void Initialize()
        {
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            backgroundTexture = Content.Load<Texture2D>("background");
            customerTexture = Content.Load<Texture2D>("customer");
            playerTexture = Content.Load<Texture2D>("pers");
            font = Content.Load<SpriteFont>("Dish");
            runnerTexture = Content.Load<Texture2D>("pers");

            Dictionary<string, Texture2D> dishTextures = new Dictionary<string, Texture2D>
            {
                {"Торт", Content.Load<Texture2D>("cake")},
                {"Мороженное", Content.Load<Texture2D>("icecream")},
                {"Кекс", Content.Load<Texture2D>("keks")},
                {"Шашлык", Content.Load<Texture2D>("shahlik")},
                {"Курица", Content.Load<Texture2D>("chicken")},
                {"Пельмени", Content.Load<Texture2D>("pelmeni")},
                {"Шаурма", Content.Load<Texture2D>("shaurma")},
                {"Лосось", Content.Load<Texture2D>("salmon")},
                {"Суши", Content.Load<Texture2D>("sushi")},
                {"Уха", Content.Load<Texture2D>("uha")}
            };

            Vector2 playerScale = new Vector2(100.0f / playerTexture.Width, 100.0f / playerTexture.Height);
            int screenWidth = GraphicsDevice.Viewport.Width;
            int screenHeight = GraphicsDevice.Viewport.Height;

            Dictionary<string, DishCategory> allDishes = new Dictionary<string, DishCategory>
            {
                {"Торт", DishCategory.Dessert},
                {"Мороженное", DishCategory.Dessert},
                {"Кекс", DishCategory.Dessert},
                {"Шашлык", DishCategory.Meat},
                {"Курица", DishCategory.Meat},
                {"Пельмени", DishCategory.Meat},
                {"Шаурма", DishCategory.Meat},
                {"Лосось", DishCategory.Fish},
                {"Суши", DishCategory.Fish},
                {"Уха", DishCategory.Fish}
            };

            dishManager = new DishManager(screenWidth, screenHeight, dishTextures);
            customer = new Customer(customerTexture, screenWidth, allDishes, dishManager, new List<string>(allDishes.Keys));
            player = new Player(playerTexture, screenWidth, screenHeight);
            runner = new Runner(runnerTexture, screenWidth, screenHeight, playerScale, false);
            leftRunner = new Runner(runnerTexture, screenWidth, screenHeight, playerScale, true);
            mainMenu = new MainMenu(font, backgroundTexture, screenWidth, screenHeight);
        }

        public void StartGame()
        {
            gameStarted = true;
        }

        protected override void Update(GameTime gameTime)
        {
            if (!gameStarted)
            {
                mainMenu.Update(this, gameTime);
            }
            else
            {
                KeyboardState keyboardState = Keyboard.GetState();
                if (keyboardState.IsKeyDown(Keys.Escape))
                {
                    gameStarted = false;
                }

                customer.Update(gameTime, player);
                player.Update(gameTime, dishManager, keyboardState, customer);
                runner.Update(gameTime);
                leftRunner.Update(gameTime);

                if (runner.CheckCollision(player.Bounds, player, dishManager) || leftRunner.CheckCollision(player.Bounds, player, dishManager))
                {
                    player.DropDish();
                }

                if (player.Score <= -10)
                {
                    Exit();
                }
            }
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();
            if (!gameStarted)
            {
                mainMenu.Draw(spriteBatch);
            }
            else
            {
                spriteBatch.Draw(backgroundTexture, new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), Color.White);
                player.Draw(spriteBatch, font);
                customer.Draw(spriteBatch, font);
                dishManager.Draw(spriteBatch);
                string scoreText = $"Score: {player.Score}";
                Vector2 scorePosition = new Vector2(10, 10);
                spriteBatch.DrawString(font, scoreText, scorePosition, Color.White);
                if (player.Score <= -6)
                {
                    string warningText = "Внимание: Гость скоро уйдет!";
                    Vector2 warningPosition = new Vector2(10, 30);
                    spriteBatch.DrawString(font, warningText, warningPosition, Color.Red);
                }
                runner.Draw(spriteBatch);
                leftRunner.Draw(spriteBatch);
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }

    }
}
