﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;
using System.Linq;

public class DishManager
{
    private List<Dish> dishes;
    private Dictionary<string, Texture2D> textures;
    private int screenWidth;
    private int screenHeight;

    public DishManager(int screenWidth, int screenHeight, Dictionary<string, Texture2D> textures)
    {
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.textures = textures;
        dishes = new List<Dish>();
    }

    public void AddDish(string name, DishCategory category)
    {
        if (!textures.ContainsKey(name) || Exists(name))
            return;

        Texture2D texture = textures[name];
        Vector2 position = CalculatePositionForCategory(category);
        dishes.Add(new Dish(name, category, position, texture));
    }


    public bool Exists(string name)
    {
        return dishes.Any(d => d.Name == name);
    }

    public void Draw(SpriteBatch spriteBatch)
    {
        foreach (var dish in dishes)
        {
            dish.Draw(spriteBatch);
        }
    }

    public Dish PickUpDish(Vector2 playerPosition)
    {
        foreach (var dish in dishes)
        {
            if (Vector2.Distance(playerPosition, dish.Position) < 60)
            {
                dishes.Remove(dish);
                return dish;
            }
        }
        return null;
    }

    public void ReturnDishToPosition(Dish dish)
    {
        dish.ResetPosition();
        if (!dishes.Contains(dish))
        {
            dishes.Add(dish);
        }
    }

    private Vector2 CalculatePositionForCategory(DishCategory category)
    {
        float x;
        float y = screenHeight - 100;
        int spacing = 10;
        int textureSize = 64;

        switch (category)
        {
            case DishCategory.Meat:
                x = 100;
                break;
            case DishCategory.Fish:
                x = (screenWidth / 3) + 100;
                break;
            case DishCategory.Dessert:
                x = (2 * (screenWidth / 3)) + 100;
                break;
            default:
                x = 100;
                break;
        }

        while (IsPosition(new Vector2(x, y)))
        {
            x += textureSize + spacing;
        }

        return new Vector2(x, y);
    }

    private bool IsPosition(Vector2 position)
    {
        int textureSize = 64;
        foreach (var dish in dishes)
        {
            if (Vector2.Distance(dish.Position, position) < textureSize)
            {
                return true;
            }
        }
        return false;
    }

}

