﻿
using var game = new kitchen.Game1();
game.Run();

