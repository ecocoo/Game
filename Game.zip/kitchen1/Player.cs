﻿using kitchen;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

public class Player
{
    public Rectangle Bounds { get; set; }
    public Vector2 Position { get; set; }
    private Texture2D texture;
    public float Speed { get; set; }
    private int screenWidth;
    private int screenHeight;
    private Dish heldDish;
    public int Score { get; private set; }
    public Dish HeldDish => heldDish;

    public Player(Texture2D texture, int screenWidth, int screenHeight)
    {
        this.texture = texture;
        Speed = 3f;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        Position = new Vector2(screenWidth / 2 - 25, screenHeight / 2 - 25);
        Bounds = new Rectangle((int)Position.X, (int)Position.Y, 100, 100);
        heldDish = null;
        Score = 0;
    }

    public void Update(GameTime gameTime, DishManager dishManager, KeyboardState keyboardState, Customer customer)
    {
        Vector2 positionChange = Vector2.Zero;

        if (keyboardState.IsKeyDown(Keys.W)) { positionChange.Y -= Speed; }
        if (keyboardState.IsKeyDown(Keys.S)) { positionChange.Y += Speed; }
        if (keyboardState.IsKeyDown(Keys.A)) { positionChange.X -= Speed; }
        if (keyboardState.IsKeyDown(Keys.D)) { positionChange.X += Speed; }

        if (keyboardState.IsKeyDown(Keys.F) && heldDish == null)
        {
            heldDish = dishManager.PickUpDish(Position);
        }

        if (keyboardState.IsKeyDown(Keys.Space) && IsHoldingDish())
        {
            DropDish();
            DecreaseScore(1);
        }

        if (keyboardState.IsKeyDown(Keys.R))
        {
            if (heldDish != null && customer.PositionClose(Position))
            {
                customer.ReceiveDish(heldDish, this);
            }
        }

        Position += positionChange;
        Position = Vector2.Clamp(Position, Vector2.Zero, new Vector2(screenWidth - Bounds.Width, screenHeight - Bounds.Height));
        Bounds = new Rectangle((int)Position.X, (int)Position.Y, Bounds.Width, Bounds.Height);
    }

    public void DropDish()
    {
        heldDish = null;
    }

    public bool IsHoldingDish()
    {
        return heldDish != null;
    }

    public void IncreaseScore(int points)
    {
        Score += points;
    }

    public void DecreaseScore(int points)
    {
        Score -= points;
    }

    public void Draw(SpriteBatch spriteBatch, SpriteFont font)
    {
        spriteBatch.Draw(texture, Bounds, Color.White);
        if (heldDish != null)
        {
            Vector2 textSize = font.MeasureString(heldDish.Name);
            Vector2 textPosition = new Vector2(Position.X + (Bounds.Width - textSize.X) / 2, Position.Y - textSize.Y - 5);
            spriteBatch.DrawString(font, heldDish.Name, textPosition, Color.Black);
        }
    }
}
