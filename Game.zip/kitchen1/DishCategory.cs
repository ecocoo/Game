﻿public enum DishCategory
{
    Meat,
    Fish, 
    Dessert  
}